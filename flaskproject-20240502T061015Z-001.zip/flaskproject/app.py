from flask import Flask, render_template,request, redirect, url_for
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database_setup import Base, Book,User
from flask_login import LoginManager, login_required,login_user,logout_user


app = Flask(__name__)
app.debug = True
app.config['SECRET_KEY'] = "secret key"
engine = create_engine('sqlite:///biblioteka.db',connect_args={'check_same_thread': False})
Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)
session = DBSession()

login_manager = LoginManager()
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return session.query(User).filter_by(id=user_id).first()

login_manager.login_view = 'login'


@app.route('/login',methods=['POST','GET'])
def login():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        user = session.query(User).filter_by(username=username).first()
        if user:
            if user.check_password(password):
                login_user(user)
                return "Авторизовані"
            else:
                return "Не вірний пароль"
    else:
        return render_template('login.html')

@app.route('/regestration',methods=['POST','GET'])
def registr():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        name = request.form['name']
        user = session.query(User).filter_by(username=username).first()
        if user:
            return "Вже існує у системі"
        else:
            user_new = User(username=username, email=email, name=name)
            user_new.set_password(password)
            session.add_all([user_new])
            session.commit()
            return "нового користувача зареэстровано у системі!"
    else:
        return render_template('registr.html')

@app.route('/logout',methods=['POST','GET'])
def logout():
    logout_user()
    return redirect(url_for('books'))


@app.route('/')
def books():
    books = session.query(Book).all()
    return render_template('books.html',books=books)


@app.route('/books/new/', methods = ["GET", "POST"])
@login_required
def newBook():
    if request.method=="POST":
        newBook = Book(title=request.form['name'], 
        author=request.form['author'],
        genre=request.form['genre'],
        year=request.form['year'],
        )
        session.add(newBook)
        session.commit()
        return redirect(url_for('books'))
    else:
        return render_template('newBook.html')

@app.route('/books/<int:book_id>/edit/', methods = ["GET", "POST"])
@login_required
def editBook(book_id):
    btd = session.query(Book).filter_by(id=book_id).first()
    if request.method=="POST":
       btd.title = request.form['name']
       btd.author=request.form['author']
       btd.genre=request.form['genre']
       btd.year=request.form['year']
       session.add(btd)
       session.commit()
       return redirect(url_for('books'))
    else:
        return render_template('editBook.html',book = btd)


@app.route('/books/<int:book_id>/delete/', methods = ["GET", "POST"])
@login_required
def deleteBook(book_id):

    btd = session.query(Book).filter_by(id=book_id).first()
    if request.method == "POST":
        session.delete(btd)
        session.commit()
        return redirect(url_for("books"))
    else:
        return render_template("deleteBook.html", book=btd) 
@app.route('/stat', methods = ["GET", "POST"])
def stat():
    booksc = session.query(Book).all()
    bookscount = len(booksc)
    return render_template("stat.html", bookscount=bookscount)
if __name__=='__main__':
    app.run(port=9639)