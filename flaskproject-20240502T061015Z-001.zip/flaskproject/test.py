from flask import Flask, render_template, request
app = Flask(__name__)
app.debug = True

@app.route('/')
def hello_world():
    return 'Hello World!'

@app.route('/test')
def test():
    _str = "TEST" + "....."
    list_example = [1,2,'q','er',4]
    return render_template('index.html', _str=_str, list_=list_example)

@app.route('/name')
def name():
    name = request.args.get('name')
    return render_template('index2.html',name_str = f"Hello {name}")

@app.route('/sum')
def sum_my():
    num1 = request.args.get('number1')
    num2 = request.args.get('number2')
    return render_template('index2.html',name_str = f"Summa =  {int(num1)+int(num2)}")

if __name__ == '__main__':
    app.run()

