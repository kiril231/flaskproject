pert = __name__

print(__main__)